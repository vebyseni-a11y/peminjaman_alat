<?php
require_once __DIR__ . '/../config/koneksi.php';

// Sudah login? langsung ke dashboard masing-masing.
if (!empty($_SESSION['id_user']) && !empty($_SESSION['level'])) {
    redirect(dashboard_path($_SESSION['level']));
}

$judul = 'Masuk';
$body_class = 'bg-ink-50';
$tanpa_layout = true;
require_once __DIR__ . '/../includes/header.php';

?>
<div class="flex min-h-screen items-center justify-center px-4 py-12">
    <div class="w-full max-w-sm">
        <div class="flex items-center justify-center gap-2">
            <span class="grid h-8 w-8 place-items-center rounded-md bg-ink-900"><svg viewBox="0 0 24 24" class="h-[55%] w-[55%]" fill="none" stroke="#fff" stroke-width="2.2" stroke-linejoin="round"><rect x="5" y="5" width="14" height="14" rx="2"/></svg></span>
            <span class="text-lg font-semibold text-ink-900">AMANAH</span>
        </div>

        <div class="card mt-8 p-6 sm:p-8">
            <h1 class="text-lg font-semibold text-ink-900">Masuk</h1>
            <p class="mt-1 text-sm text-ink-500">Gunakan username dan password dari admin.</p>

            <form action="proses_login.php" method="post" class="mt-6 space-y-4">
                <?= csrf_field() ?>
                <div>
                    <label class="label" for="username">Username</label>
                    <input class="input" type="text" id="username" name="username" autocomplete="username" placeholder="Username" required autofocus>
                </div>
                <div>
                    <label class="label" for="password">Password</label>
                    <div class="relative">
                        <input class="input pr-10" type="password" id="password" name="password" autocomplete="current-password" placeholder="Password" required>
                        <button type="button" class="absolute right-2.5 top-1/2 -translate-y-1/2 rounded p-1 text-ink-400 hover:text-ink-700" data-pass-toggle="#password" aria-label="Tampilkan password"><?= icon('eye', 'w-4 h-4') ?></button>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-full py-2.5">Masuk</button>
            </form>
        </div>

        <!-- Akun contoh: hapus blok ini saat aplikasi dipakai sungguhan -->
        <div class="mt-4 flex items-center justify-center gap-2 text-xs text-ink-500">
            <span>Akun contoh:</span>
            <?php foreach ([['admin', 'admin123'], ['petugas', 'petugas123'], ['peminjam', 'peminjam123']] as $ak): ?>
                <button type="button" class="rounded border border-ink-200 bg-white px-2 py-1 font-medium text-ink-600 hover:bg-ink-100" data-akun="<?= e($ak[0]) ?>|<?= e($ak[1]) ?>"><?= e(ucfirst($ak[0])) ?></button>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('[data-akun]').forEach(function (b) {
    b.addEventListener('click', function () {
        var p = b.getAttribute('data-akun').split('|');
        document.getElementById('username').value = p[0];
        document.getElementById('password').value = p[1];
        document.getElementById('password').focus();
    });
});
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
