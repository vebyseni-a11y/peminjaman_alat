<?php
$level_boleh = ['admin'];
require_once '../includes/auth.php';

// ---- Data ringkasan ----
$total_user      = (int)db_val($koneksi, 'SELECT COUNT(*) FROM user');
$jenis_alat      = (int)db_val($koneksi, 'SELECT COUNT(*) FROM alat');
$unit_tersedia   = (int)db_val($koneksi, 'SELECT COALESCE(SUM(stok),0) FROM alat');
$sedang_dipinjam = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE persetujuan = 1 AND status = 1');
$terlambat       = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE persetujuan = 1 AND status = 1 AND tanggal_kembali < CURDATE()');
$menunggu        = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE persetujuan = 0');

// Peminjaman 6 bulan terakhir
$nama_bulan = [1 => 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
$bulan = [];
for ($i = 5; $i >= 0; $i--) {
    $t = strtotime("first day of -$i month");
    $bulan[date('Y-m', $t)] = ['label' => $nama_bulan[(int)date('n', $t)], 'jumlah' => 0];
}
$rows = db_all($koneksi, "SELECT DATE_FORMAT(tanggal_pinjam, '%Y-%m') AS ym, COUNT(*) AS n
                          FROM peminjaman
                          WHERE tanggal_pinjam >= DATE_SUB(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 5 MONTH)
                          GROUP BY ym");
foreach ($rows as $r) {
    if (isset($bulan[$r['ym']])) {
        $bulan[$r['ym']]['jumlah'] = (int)$r['n'];
    }
}
$maks = max(1, max(array_column($bulan, 'jumlah')));

// Sebaran status
$s_menunggu = $menunggu;
$s_dipinjam = $sedang_dipinjam;
$s_kembali  = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE persetujuan = 1 AND status = 2');
$s_tolak    = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE persetujuan = 2');
$s_total    = max(1, $s_menunggu + $s_dipinjam + $s_kembali + $s_tolak);
$sebaran = [
    ['Menunggu', $s_menunggu, '#F59E0B'],
    ['Dipinjam', $s_dipinjam, '#4F46E5'],
    ['Dikembalikan', $s_kembali, '#10B981'],
    ['Ditolak', $s_tolak, '#EF4444'],
];

$terbaru = db_all($koneksi, 'SELECT p.*, u.nama AS peminjam, a.nama_alat
                             FROM peminjaman p
                             JOIN user u ON u.id_user = p.id_user
                             JOIN alat a ON a.id_alat = p.id_alat
                             ORDER BY p.id_peminjaman DESC LIMIT 6');
$log = db_all($koneksi, 'SELECT * FROM log_aktivitas ORDER BY id_log DESC LIMIT 6');
$stok_tipis = db_all($koneksi, 'SELECT a.*, k.nama_kategori FROM alat a JOIN kategori k ON k.id_kategori = a.id_kategori WHERE a.stok <= 2 ORDER BY a.stok ASC, a.nama_alat LIMIT 5');

$judul = 'Dashboard';
require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<!-- Judul -->
<section class="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
    <div>
        <p class="text-sm text-ink-500">Halo, <?= e(explode(' ', $user['nama'])[0]) ?></p>
        <h1 class="mt-1 text-xl font-semibold text-ink-900">
            <?= $menunggu > 0 ? $menunggu . ' pengajuan menunggu persetujuan' : 'Semua pengajuan sudah diproses' ?>
        </h1>
        <p class="mt-1 text-sm text-ink-500">
            <?= $sedang_dipinjam ?> alat sedang dipinjam<?= $terlambat > 0 ? ', ' . $terlambat . ' terlambat dikembalikan' : '' ?>.
        </p>
    </div>
    <div class="flex gap-2">
        <a href="<?= url('admin/peminjaman.php' . ($menunggu > 0 ? '?filter=menunggu' : '')) ?>" class="btn btn-primary">Lihat peminjaman</a>
        <a href="<?= url('admin/alat.php') ?>" class="btn btn-ghost"><?= icon('plus', 'w-4 h-4') ?> Tambah alat</a>
    </div>
</section>

<!-- Statistik -->
<section class="mt-6 grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-ink-200 bg-ink-200 lg:grid-cols-4">
    <?php
    $stat = [
        ['Total pengguna', $total_user, 'admin/user.php', 'Admin, petugas, peminjam'],
        ['Unit tersedia', $unit_tersedia, 'admin/alat.php', $jenis_alat . ' jenis alat'],
        ['Sedang dipinjam', $sedang_dipinjam, 'admin/peminjaman.php?filter=dipinjam', $terlambat . ' terlambat'],
        ['Menunggu persetujuan', $menunggu, 'admin/peminjaman.php?filter=menunggu', 'Perlu ditindaklanjuti'],
    ];
    foreach ($stat as $s): ?>
        <a href="<?= url($s[2]) ?>" class="bg-white p-5 transition-colors hover:bg-ink-50">
            <p class="text-xs text-ink-500"><?= e($s[0]) ?></p>
            <p class="mt-1 text-2xl font-semibold text-ink-900" data-count="<?= (int)$s[1] ?>"><?= (int)$s[1] ?></p>
            <p class="mt-0.5 text-xs text-ink-400"><?= e($s[3]) ?></p>
        </a>
    <?php endforeach; ?>
</section>

<!-- Grafik -->
<section class="mt-6 grid gap-6 lg:grid-cols-3">
    <div class="card p-6 lg:col-span-2">
        <div class="flex items-start justify-between gap-4">
            <div>
                <h3 class="text-lg font-semibold text-ink-900">Peminjaman per bulan</h3>
                <p class="text-sm text-ink-500">Jumlah pengajuan dalam 6 bulan terakhir</p>
            </div>
            <span class="badge badge-gray"><?= array_sum(array_column($bulan, 'jumlah')) ?> total</span>
        </div>
        <div class="mt-8 flex h-52 items-end gap-3 sm:gap-5">
            <?php $n = 0; foreach ($bulan as $b):
                $tinggi = $b['jumlah'] > 0 ? max(8, round($b['jumlah'] / $maks * 100)) : 4; ?>
                <div class="flex h-full flex-1 flex-col items-center justify-end gap-2">
                    <span class="text-xs font-semibold text-ink-700"><?= $b['jumlah'] ?></span>
                    <div class="w-full max-w-[3.5rem] rounded-t <?= $b['jumlah'] === $maks && $maks > 0 ? 'bg-brand-600' : 'bg-ink-200' ?>" style="height:<?= $tinggi ?>%"></div>
                    <span class="text-xs font-semibold text-ink-500"><?= e($b['label']) ?></span>
                </div>
            <?php $n++; endforeach; ?>
        </div>
    </div>

    <div class="card p-6">
        <h3 class="text-lg font-semibold text-ink-900">Status peminjaman</h3>
        <p class="text-sm text-ink-500">Seluruh pengajuan yang pernah masuk</p>
        <div class="mt-6 flex h-4 overflow-hidden rounded-full bg-ink-100">
            <?php foreach ($sebaran as $s): if ($s[1] > 0): ?>
                <div class="h-full transition-all" style="width:<?= round($s[1] / $s_total * 100, 1) ?>%;background:<?= $s[2] ?>" title="<?= e($s[0]) ?>: <?= $s[1] ?>"></div>
            <?php endif; endforeach; ?>
        </div>
        <ul class="mt-6 space-y-3">
            <?php foreach ($sebaran as $s): ?>
                <li class="flex items-center justify-between text-sm">
                    <span class="flex items-center gap-2.5 font-semibold text-ink-700"><span class="h-3 w-3 rounded-full" style="background:<?= $s[2] ?>"></span><?= e($s[0]) ?></span>
                    <span class="font-semibold text-ink-900"><?= $s[1] ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>

<!-- Tabel & aktivitas -->
<section class="mt-6 grid gap-6 lg:grid-cols-3">
    <div class="card overflow-hidden lg:col-span-2">
        <div class="flex items-center justify-between p-6 pb-4">
            <h3 class="text-lg font-semibold text-ink-900">Peminjaman terbaru</h3>
            <a href="<?= url('admin/peminjaman.php') ?>" class="text-sm font-semibold text-brand-700 hover:underline">Lihat semua</a>
        </div>
        <div class="overflow-x-auto scroll-thin">
            <table class="tbl">
                <thead><tr><th>Peminjam</th><th>Alat</th><th>Tanggal pinjam</th><th>Status</th></tr></thead>
                <tbody>
                <?php foreach ($terbaru as $r): ?>
                    <tr>
                        <td class="font-semibold text-ink-900"><?= e($r['peminjam']) ?></td>
                        <td><?= e($r['nama_alat']) ?></td>
                        <td class="whitespace-nowrap text-ink-500"><?= tgl($r['tanggal_pinjam']) ?></td>
                        <td><?= badge_status($r) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$terbaru): ?><tr><td colspan="4" class="py-10 text-center text-ink-500">Belum ada peminjaman.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="space-y-6">
        <div class="card p-6">
            <h3 class="text-lg font-semibold text-ink-900">Stok menipis</h3>
            <ul class="mt-4 space-y-3">
                <?php foreach ($stok_tipis as $a): ?>
                    <li class="flex items-center gap-3">
                        <span class="grid h-10 w-10 shrink-0 place-items-center rounded-md text-white" style="<?= kategori_gradien($a['id_kategori']) ?>"><?= icon(kategori_ikon($a['nama_kategori']), 'w-5 h-5') ?></span>
                        <div class="min-w-0 flex-1 leading-tight">
                            <p class="truncate text-sm font-semibold text-ink-900"><?= e($a['nama_alat']) ?></p>
                            <p class="text-xs text-ink-500"><?= e($a['nama_kategori']) ?></p>
                        </div>
                        <span class="badge <?= (int)$a['stok'] === 0 ? 'badge-red' : 'badge-amber' ?>"><?= (int)$a['stok'] === 0 ? 'Habis' : 'Sisa ' . (int)$a['stok'] ?></span>
                    </li>
                <?php endforeach; ?>
                <?php if (!$stok_tipis): ?><li class="text-sm text-ink-500">Semua stok aman.</li><?php endif; ?>
            </ul>
        </div>

        <div class="card p-6">
            <div class="flex items-center justify-between">
                <h3 class="text-lg font-semibold text-ink-900">Aktivitas terakhir</h3>
                <a href="<?= url('admin/log_aktivitas.php') ?>" class="text-sm font-semibold text-brand-700 hover:underline">Semua</a>
            </div>
            <ol class="relative mt-4 space-y-4 border-l border-ink-100 pl-5">
                <?php foreach ($log as $l): ?>
                    <li class="relative">
                        <span class="absolute -left-[26px] top-1.5 h-2.5 w-2.5 rounded-full bg-ink-400 ring-4 ring-white"></span>
                        <p class="text-sm leading-snug text-ink-700"><?= e($l['aktivitas']) ?></p>
                        <p class="text-xs text-ink-400"><?= tgl($l['tanggal']) ?></p>
                    </li>
                <?php endforeach; ?>
                <?php if (!$log): ?><li class="text-sm text-ink-500">Belum ada aktivitas.</li><?php endif; ?>
            </ol>
        </div>
    </div>
</section>

<?php require_once '../includes/footer.php'; ?>
