<?php
/**
 * includes/header.php → <head> + Tema Burgundy Pekat + Anime & Elektronik Visual (Fix Tabel Putih)
 */
$judul = isset($judul) ? $judul : 'Beranda';
$body_class = isset($body_class) ? $body_class : 'bg-[#1a0307] text-stone-100';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($judul) ?> · AMANAH</title>
    <meta name="theme-color" content="#21040a">
    
    <!-- Favicon Elegan Burgundy, Kupu-kupu & Elektronik -->
    <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='16' fill='%233c0a15'/%3E%3Cpath d='M16 20h32v20H16z' fill='none' stroke='%23fbcfe8' stroke-width='4' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M32 10c2-4 6-4 8 0s-2 6-8 8c-6-2-10-6-8-8s6-4 8 0z' fill='%23fbcfe8'/%3E%3C/svg%3E">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'ui-sans-serif', 'system-ui', 'sans-serif']
                    },
                    colors: {
                        burgundy: {
                            50: '#fdf2f4',
                            100: '#fbe5e9',
                            200: '#f7ced7',
                            300: '#f1a7b8',
                            400: '#e5738f',
                            500: '#d44368',
                            600: '#be2951',
                            700: '#a01e40',
                            800: '#851b37',
                            900: '#581c27',
                            950: '#3c0a15',
                            darkest: '#21040a'
                        }
                    }
                }
            }
        };
    </script>

    <style type="text/tailwindcss">
        @layer base {
            body { @apply font-sans text-sm text-stone-200 antialiased selection:bg-burgundy-600 selection:text-white bg-[#21040a]; }
            h1, h2, h3 { @apply text-white font-extrabold tracking-tight; }
            :focus-visible { outline: 2px solid #e5738f; outline-offset: 2px; }
            
            /* MEMPERBAIKI TABEL & KARTU BAWAAN AGAR TIDAK PUTIH TERANG */
            table, th, td { color: #f5f5f4 !important; }
            .card, div[class*="bg-white"], .bg-white { background-color: #310811 !important; color: #f5f5f4 !important; border-color: #851b37 !important; }
        }
        @layer components {
            .btn { @apply inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold transition-all shadow-md active:scale-95 disabled:opacity-50 disabled:pointer-events-none whitespace-nowrap; }
            .btn-sm { @apply px-3 py-1.5 text-xs gap-1.5 rounded-xl; }
            .btn-primary { @apply bg-gradient-to-r from-burgundy-700 to-burgundy-900 text-white hover:from-burgundy-600 hover:to-burgundy-800 shadow-burgundy-950/80 border border-burgundy-600/30; }
            .btn-dark { @apply bg-stone-900 text-white hover:bg-stone-800 border border-stone-800; }
            .btn-soft { @apply bg-burgundy-950/80 text-rose-200 hover:bg-burgundy-900 border border-burgundy-800/60; }
            .btn-ghost { @apply border border-burgundy-800/80 bg-burgundy-950/60 backdrop-blur text-stone-200 hover:bg-burgundy-900; }
            .btn-danger { @apply bg-red-600 text-white hover:bg-red-700 shadow-lg shadow-red-950/50; }
            .btn-danger-soft { @apply border border-red-900/50 bg-burgundy-950 text-red-400 hover:bg-red-950/80; }
            .input { @apply w-full rounded-2xl border border-burgundy-800/80 bg-[#2d060e] px-4 py-2.5 text-sm text-white placeholder:text-stone-500 transition-all focus:border-burgundy-400 focus:outline-none focus:ring-4 focus:ring-burgundy-500/30 shadow-inner; }
            .label { @apply mb-1.5 block text-xs font-bold uppercase tracking-wider text-rose-300/90; }
            .card { @apply rounded-3xl border border-burgundy-900/80 bg-[#310811]/90 backdrop-blur-xl shadow-2xl shadow-black/60; }
            .badge { @apply inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1 text-xs font-bold ring-1 ring-inset; }
            .badge i { @apply block h-1.5 w-1.5 rounded-full bg-current; }
            .badge-amber { @apply bg-amber-950/80 text-amber-300 ring-amber-500/40; }
            .badge-green { @apply bg-emerald-950/80 text-emerald-300 ring-emerald-500/40; }
            .badge-red { @apply bg-burgundy-950 text-rose-300 ring-burgundy-500/40; }
            .badge-blue { @apply bg-sky-950/80 text-sky-300 ring-sky-500/40; }
            .badge-violet { @apply bg-violet-950/80 text-violet-300 ring-violet-500/40; }
            .badge-gray { @apply bg-stone-900 text-stone-300 ring-stone-700/40; }
            .tbl { @apply w-full text-sm; }
            .tbl th { @apply whitespace-nowrap border-b border-burgundy-900 bg-[#2d060e] px-4 py-3.5 text-left text-xs font-extrabold uppercase tracking-wider text-rose-200; }
            .tbl td { @apply border-b border-burgundy-950 px-4 py-4 align-middle text-stone-300; }
            .tbl tbody tr:last-child td { @apply border-b-0; }
            .tbl tbody tr { @apply transition-colors hover:bg-burgundy-900/40; }
            .chip { @apply inline-flex items-center gap-1.5 rounded-full border border-burgundy-800 bg-[#310811] px-3.5 py-1.5 text-sm font-medium text-stone-300 transition-all hover:bg-burgundy-900 hover:text-white shadow-sm; }
            .chip-on { @apply border-burgundy-400 bg-burgundy-900 text-white ring-2 ring-burgundy-500/40; }
            .nav-link { @apply flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold text-rose-100/70 transition-all hover:bg-burgundy-800/50 hover:text-white; }
            .nav-link-on { @apply bg-gradient-to-r from-burgundy-700 to-burgundy-800 text-white font-bold shadow-lg shadow-burgundy-950/60 border-l-4 border-rose-300; }
        }
    </style>

    <style>
        .scroll-thin::-webkit-scrollbar { width: 6px; height: 6px; }
        .scroll-thin::-webkit-scrollbar-thumb { background: #851b37; border-radius: 999px; }
        .modal { position: fixed; inset: 0; z-index: 60; display: none; align-items: center; justify-content: center; padding: 1rem; }
        .modal.open { display: flex; }
        .modal-bg { position: absolute; inset: 0; background: rgba(10, 1, 3, 0.8); backdrop-filter: blur(6px); }
        .modal-box { position: relative; width: 100%; max-width: 32rem; max-height: 90vh; overflow-y: auto; border-radius: 1.5rem; background: #310811; border: 1px solid #851b37; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.8); }
        
        .bg-burgundy-anime-glow {
            background-color: #21040a;
            background-image: 
                radial-gradient(circle at 10% 10%, rgba(133, 27, 55, 0.25) 0%, transparent 45%),
                radial-gradient(circle at 90% 90%, rgba(212, 67, 104, 0.15) 0%, transparent 45%);
        }
        @keyframes floatAnime {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-8px) rotate(2deg); }
        }
        .anime-float { animation: floatAnime 4s ease-in-out infinite; }
        @media print { .no-print { display: none !important; } }
    </style>
</head>
<body class="<?= e($body_class) ?> bg-burgundy-anime-glow min-h-screen">