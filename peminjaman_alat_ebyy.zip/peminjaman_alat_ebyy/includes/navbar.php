<?php
/**
 * includes/navbar.php → Sidebar Burgundy Pekat + Anime & Elektronik (Laptop/HP/Gadget)
 */
$menu_aktif = basename($_SERVER['SCRIPT_NAME'], '.php');

$menus = [
    'admin' => [
        ['dashboard', 'Dashboard', 'grid', '📊'],
        ['user', 'Pengguna', 'users', '👤'],
        ['kategori', 'Kategori', 'tag', '🏷️'],
        ['alat', 'Alat', 'box', '💻'], /* Ikon Laptop/Alat */
        ['peminjaman', 'Peminjaman', 'clipboard', '📋'],
        ['pengembalian', 'Pengembalian', 'return', '📱'], /* Ikon Gadget/HP */
        ['log_aktivitas', 'Log', 'activity', '📝'],
    ],
    'petugas' => [
        ['dashboard', 'Dashboard', 'grid', '📊'],
        ['peminjaman', 'Peminjaman', 'clipboard', '📋'],
        ['setujui', 'Persetujuan', 'check', '✅'],
        ['pengembalian', 'Pengembalian', 'return', '📱'],
        ['cetak', 'Laporan', 'printer', '🖨️'],
    ],
    'peminjam' => [
        ['dashboard', 'Beranda', 'home', '🌸'],
        ['daftar_alat', 'Katalog Elektronik', 'grid', '💻'],
        ['pinjam', 'Ajukan Pinjam', 'plus', '✨'],
        ['riwayat', 'Riwayat', 'clock', '⏳'],
    ],
];

$user_level = $user['level'] ?? 'peminjam';
$menu = $menus[$user_level] ?? [];

$jumlah_menunggu = 0;
if ($user_level !== 'peminjam' && isset($koneksi)) {
    $jumlah_menunggu = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE persetujuan = 0');
}
?>

<div class="flex min-h-screen">
    <!-- SIDEBAR BURGUNDY PEKAT (Kupu-kupu, Anime & Elektronik) -->
    <aside class="w-64 bg-[#2b050d] border-r border-burgundy-900/60 text-white flex flex-col justify-between p-4 sticky top-0 h-screen shadow-2xl z-20 overflow-hidden no-print shrink-0">
        
        <!-- Hiasan Anime & Kupu-kupu Transparan di Background Sidebar -->
        <div aria-hidden="true" class="absolute -top-10 -right-10 opacity-15 pointer-events-none text-rose-300 anime-float">
            <svg width="220" height="220" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
            </svg>
        </div>

        <div class="relative z-10">
            <!-- Header Brand AMANAH + Anime & Elektronik Badge -->
            <a href="<?= url($user_level . '/dashboard.php') ?>" class="flex items-center gap-3 px-3 py-4 mb-6 border-b border-burgundy-900/80 group">
                <div class="w-11 h-11 rounded-2xl bg-gradient-to-br from-burgundy-600 to-burgundy-900 border border-rose-400/30 flex items-center justify-center text-rose-200 shadow-lg anime-float">
                    <!-- Ikon Kupu-kupu & Laptop Anime Style -->
                    <span class="text-xl">🦋</span>
                </div>
                <div>
                    <h1 class="text-lg font-black text-white tracking-wider group-hover:text-rose-300 transition-colors">AMANAH</h1>
                    <p class="text-[9px] text-rose-300/80 font-bold tracking-widest uppercase">✨ Sistem Elektronik</p>
                </div>
            </a>

            <!-- Menu Navigasi Samping -->
            <nav class="space-y-1.5 overflow-y-auto max-h-[calc(100vh-250px)] scroll-thin pr-1">
                <?php foreach ($menu as $m):
                    $on = $menu_aktif === $m[0];
                    $notif = ($m[0] === 'setujui' || ($user_level === 'admin' && $m[0] === 'peminjaman')) && $jumlah_menunggu > 0;
                ?>
                    <a href="<?= url($user_level . '/' . $m[0] . '.php') ?>" class="nav-link <?= $on ? 'nav-link-on' : '' ?>">
                        <span class="text-base"><?= $m[3] ?? '🔹' ?></span>
                        <span class="flex-1"><?= e($m[1]) ?></span>
                        <?php if ($notif): ?>
                            <span class="rounded-full bg-rose-500 px-2 py-0.5 text-[10px] font-extrabold text-white shadow-md animate-pulse"><?= $jumlah_menunggu ?></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </nav>
        </div>

        <!-- Profil & Tombol Keluar (Burgundy Gelap) -->
        <div class="relative z-10 pt-4 border-t border-burgundy-900/80 space-y-3">
            <div class="p-3 bg-[#1d0308] rounded-2xl border border-burgundy-900 flex items-center gap-3 shadow-inner">
                <div class="w-9 h-9 rounded-xl bg-burgundy-700 flex items-center justify-center font-bold text-xs text-rose-200 shadow-md">
                    <?= strtoupper(substr($user['nama'] ?? 'A', 0, 1)) ?>
                </div>
                <div class="overflow-hidden flex-1">
                    <p class="text-xs font-bold text-white truncate"><?= e($user['nama'] ?? 'Pengguna') ?></p>
                    <p class="text-[10px] text-rose-300/70 uppercase tracking-wider truncate font-semibold"><?= e($user_level) ?> 🌸</p>
                </div>
            </div>
            <a href="<?= url('auth/logout.php') ?>" class="w-full btn bg-burgundy-950 hover:bg-red-700 text-rose-100 text-xs py-2.5 justify-center transition-colors border border-burgundy-800/80 shadow-lg">
                <?= icon('logout', 'w-3.5 h-3.5') ?> Keluar Sistem
            </a>
        </div>
    </aside>

    <!-- KONTEN UTAMA SISI KANAN -->
    <div class="flex-1 flex flex-col min-w-0">
        <!-- Top Bar Burgundy Pekat -->
        <header class="bg-[#2b050d]/90 backdrop-blur border-b border-burgundy-900/80 px-6 py-4 sticky top-0 z-10 flex items-center justify-between no-print shadow-md">
            <div class="flex items-center gap-3">
                <span class="text-xs font-black uppercase tracking-wider text-rose-200 bg-burgundy-900/80 px-3 py-1 rounded-lg border border-burgundy-700/50 shadow-sm">
                    ✨ <?= ucfirst($user_level) ?> Panel · AMANAH
                </span>
                <span class="hidden md:inline-flex items-center gap-1 text-xs text-rose-300/70 font-medium">
                    💻 Peminjaman Amanah Mudah Dan Cepat 🦋
                </span>
            </div>
            <div class="flex items-center gap-3">
                <span class="text-sm font-medium text-stone-300">Halo, <strong class="text-white"><?= e($user['nama'] ?? 'Pengguna') ?></strong></span>
            </div>
        </header>

        <!-- Wadah Konten -->
        <main class="flex-1 p-6 lg:p-8 overflow-y-auto">
            <div class="mx-auto max-w-6xl">