<?php
$level_boleh = ['peminjam'];
require_once '../includes/auth.php';

$id = $user['id'];
$aktif     = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE id_user = ? AND persetujuan = 1 AND status = 1', [$id]);
$menunggu  = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE id_user = ? AND persetujuan = 0', [$id]);
$selesai   = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE id_user = ? AND status = 2', [$id]);

$kategori = db_all($koneksi, 'SELECT k.*, COUNT(a.id_alat) AS jenis FROM kategori k LEFT JOIN alat a ON a.id_kategori = k.id_kategori GROUP BY k.id_kategori ORDER BY k.nama_kategori');
$pilihan = db_all($koneksi, "SELECT a.*, k.nama_kategori FROM alat a JOIN kategori k ON k.id_kategori = a.id_kategori
                             WHERE a.stok > 0 AND a.kondisi NOT LIKE '%berat%'
                             ORDER BY (SELECT COUNT(*) FROM peminjaman p WHERE p.id_alat = a.id_alat) DESC, a.nama_alat LIMIT 4");
$pinjaman = db_all($koneksi, 'SELECT p.*, a.nama_alat, a.id_kategori, k.nama_kategori
                              FROM peminjaman p JOIN alat a ON a.id_alat = p.id_alat JOIN kategori k ON k.id_kategori = a.id_kategori
                              WHERE p.id_user = ? AND ((p.persetujuan = 1 AND p.status = 1) OR p.persetujuan = 0)
                              ORDER BY p.tanggal_kembali ASC LIMIT 4', [$id]);

$judul = 'Beranda';
require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="mx-auto max-w-6xl space-y-10 px-4 py-8 sm:px-6 lg:px-8">

    <!-- Sapaan + pencarian -->
    <section>
        <p class="text-sm text-ink-500">Halo, <?= e(explode(' ', $user['nama'])[0]) ?></p>
        <h1 class="mt-1 text-2xl font-semibold text-ink-900">Butuh alat apa hari ini?</h1>
        <form action="daftar_alat.php" method="get" class="mt-5 flex max-w-xl gap-2">
            <div class="relative flex-1">
                <span class="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"><?= icon('search', 'w-4 h-4') ?></span>
                <input type="search" name="q" class="input pl-9" placeholder="Cari laptop, proyektor, kamera..." aria-label="Cari alat">
            </div>
            <button class="btn btn-dark">Cari</button>
        </form>
    </section>

    <!-- Ringkasan -->
    <section class="grid grid-cols-3 divide-x divide-ink-200 rounded-lg border border-ink-200 bg-white">
        <?php foreach ([['Dipinjam', $aktif], ['Menunggu', $menunggu], ['Selesai', $selesai]] as $s): ?>
            <div class="p-4 sm:p-5">
                <p class="text-xs text-ink-500"><?= e($s[0]) ?></p>
                <p class="mt-1 text-2xl font-semibold text-ink-900" data-count="<?= (int)$s[1] ?>"><?= (int)$s[1] ?></p>
            </div>
        <?php endforeach; ?>
    </section>

    <!-- Pinjaman saya -->
    <?php if ($pinjaman): ?>
    <section>
        <div class="flex items-center justify-between">
            <h2 class="text-base font-semibold text-ink-900">Pinjaman saya</h2>
            <a href="<?= url('peminjam/riwayat.php') ?>" class="text-sm font-medium text-brand-600 hover:underline">Semua riwayat</a>
        </div>
        <div class="card mt-3 divide-y divide-ink-100">
            <?php foreach ($pinjaman as $p):
                $telat = (int)$p['persetujuan'] === 1 && $p['tanggal_kembali'] < date('Y-m-d');
                $sisa = hari_selisih(date('Y-m-d'), $p['tanggal_kembali']); ?>
                <article class="flex items-center gap-4 p-4">
                    <span class="grid h-10 w-10 shrink-0 place-items-center rounded-md" style="<?= kategori_gradien($p['id_kategori']) ?>"><?= icon(kategori_ikon($p['nama_kategori']), 'w-5 h-5') ?></span>
                    <div class="min-w-0 flex-1">
                        <h3 class="truncate text-sm font-medium text-ink-900"><?= e($p['nama_alat']) ?></h3>
                        <p class="text-sm text-ink-500">
                            <?php if ((int)$p['persetujuan'] === 0): ?>Diajukan untuk <?= tgl($p['tanggal_pinjam']) ?>
                            <?php elseif ($telat): ?>Seharusnya kembali <?= tgl($p['tanggal_kembali']) ?>
                            <?php else: ?>Kembalikan <?= $sisa <= 0 ? 'hari ini' : 'dalam ' . $sisa . ' hari' ?><?php endif; ?>
                        </p>
                    </div>
                    <?= badge_status($p) ?>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- Kategori -->
    <section>
        <div class="flex items-center justify-between">
            <h2 class="text-base font-semibold text-ink-900">Kategori</h2>
            <a href="<?= url('peminjam/daftar_alat.php') ?>" class="text-sm font-medium text-brand-600 hover:underline">Lihat semua alat</a>
        </div>
        <div class="mt-3 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-5">
            <?php foreach ($kategori as $k): ?>
                <a href="<?= url('peminjam/daftar_alat.php?kategori=' . (int)$k['id_kategori']) ?>" class="card flex items-center gap-3 p-4 transition-colors hover:border-ink-300 hover:bg-ink-50">
                    <span class="text-ink-500"><?= icon(kategori_ikon($k['nama_kategori']), 'w-5 h-5') ?></span>
                    <div class="min-w-0 leading-tight">
                        <p class="truncate text-sm font-medium text-ink-900"><?= e($k['nama_kategori']) ?></p>
                        <p class="text-xs text-ink-500"><?= (int)$k['jenis'] ?> jenis</p>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Pilihan populer -->
    <section>
        <h2 class="text-base font-semibold text-ink-900">Paling sering dipinjam</h2>
        <div class="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <?php foreach ($pilihan as $a) { echo kartu_alat($a); } ?>
        </div>
        <?php if (!$pilihan): ?><div class="card py-12 text-center text-sm text-ink-500">Belum ada alat yang tersedia.</div><?php endif; ?>
    </section>
</div>

<?php require_once '../includes/footer.php'; ?>
