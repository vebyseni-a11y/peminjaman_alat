<?php
/**
 * includes/footer.php → Penutup Layout Burgundy Pekat, Notifikasi & JS
 */
$tanpa_layout = isset($tanpa_layout) ? $tanpa_layout : false;
$flash = flash_ambil();
?>

<?php if (!$tanpa_layout): ?>
        </div> <!-- Penutup max-w-6xl -->
    </main> <!-- Penutup main -->

    <!-- FOOTER AMANAH BURGUNDY -->
    <footer class="border-t border-burgundy-900/80 bg-[#2b050d] no-print mt-auto text-stone-400">
        <div class="mx-auto flex max-w-6xl flex-col gap-2 px-6 py-5 text-xs sm:flex-row sm:items-center sm:justify-between">
            <span class="font-medium text-rose-200/90">🦋<?= date('Y') ?> <strong class="text-white">AMANAH</strong> · Sistem Peminjaman Perangkat Elektronik 💻✨ 🦋</span>
            <span class="text-rose-300/70 font-medium">Layanan Senin–Jumat, 07.30–16.00 WIB</span>
        </div>
    </footer>

</div> <!-- Penutup flex-1 flex-col -->
</div> <!-- Penutup flex min-h-screen -->
<?php endif; ?>

<!-- NOTIFIKASI TOAST (Burgundy Pekat) -->
<?php if ($flash): ?>
<div class="pointer-events-none fixed inset-x-0 top-4 z-[70] flex justify-center px-4 no-print" role="status" aria-live="polite">
    <div id="toast" class="pointer-events-auto flex max-w-md items-start gap-3 rounded-2xl border border-burgundy-700 bg-[#310811]/95 backdrop-blur-md px-4 py-3 text-sm text-stone-100 shadow-2xl shadow-black/80">
        <span class="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full <?= $flash['tipe'] === 'error' ? 'bg-red-600' : 'bg-emerald-600' ?> text-white font-bold">
            <?= icon($flash['tipe'] === 'error' ? 'alert' : 'check', 'w-3 h-3') ?>
        </span>
        <p class="leading-snug"><?= e($flash['pesan']) ?></p>
        <button type="button" class="-mr-1 ml-1 text-stone-400 hover:text-white" onclick="this.closest('#toast').remove()" aria-label="Tutup"><?= icon('x', 'w-4 h-4') ?></button>
    </div>
</div>
<?php endif; ?>

<!-- DIALOG KONFIRMASI / MODAL -->
<div id="confirm-modal" class="modal no-print" role="dialog" aria-modal="true" aria-labelledby="confirm-judul">
    <div class="modal-bg" data-modal-close></div>
    <div class="modal-box p-6 sm:max-w-sm rounded-3xl border border-burgundy-700 bg-[#310811] shadow-2xl">
        <div class="flex items-center gap-2 mb-2">
            <span class="text-lg">✨🦋</span>
            <h3 id="confirm-judul" class="text-base font-bold text-white">Lanjutkan tindakan ini?</h3>
        </div>
        <p id="confirm-teks" class="text-sm text-stone-300"></p>
        <div class="mt-6 flex justify-end gap-2">
            <button type="button" class="btn btn-ghost" data-modal-close>Batal</button>
            <button type="button" id="confirm-ok" class="btn btn-danger">Ya, lanjutkan</button>
        </div>
    </div>
</div>

<!-- JAVASCRIPT GLOBAL -->
<script>
(function () {
    var $ = function (s, r) { return (r || document).querySelector(s); };
    var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

    var toast = $('#toast');
    if (toast) setTimeout(function () { toast.remove(); }, 5000);

    $$('[data-toggle]').forEach(function (el) {
        el.addEventListener('click', function () { var t = $(el.getAttribute('data-toggle')); if (t) t.classList.toggle('hidden'); });
    });

    function modal(m, buka) {
        if (!m) return;
        m.classList.toggle('open', buka);
        document.body.style.overflow = buka ? 'hidden' : '';
        if (buka) { var f = $('input:not([type=hidden]),select,textarea', m); if (f) setTimeout(function () { f.focus(); }, 60); }
    }
    $$('[data-modal-open]').forEach(function (el) {
        el.addEventListener('click', function () {
            var m = $(el.getAttribute('data-modal-open'));
            if (!m) return;
            var form = $('form', m);
            if (form) {
                form.reset();
                var data = el.getAttribute('data-json');
                data = data ? JSON.parse(data) : {};
                $$('[name]', form).forEach(function (inp) {
                    if (inp.name === 'csrf' || inp.name === 'aksi') return;
                    if (Object.prototype.hasOwnProperty.call(data, inp.name)) inp.value = data[inp.name];
                });
                var judul = $('[data-modal-title]', m);
                if (judul && el.getAttribute('data-title')) judul.textContent = el.getAttribute('data-title');
                var aksi = $('input[name=aksi]', form);
                if (aksi && el.getAttribute('data-aksi')) aksi.value = el.getAttribute('data-aksi');
            }
            modal(m, true);
        });
    });
    $$('[data-modal-close]').forEach(function (el) {
        el.addEventListener('click', function () { modal(el.closest('.modal'), false); });
    });
    document.addEventListener('keydown', function (ev) {
        if (ev.key === 'Escape') { $$('.modal.open').forEach(function (m) { modal(m, false); }); }
    });

    var cm = $('#confirm-modal'), pending = null;
    $$('form[data-confirm]').forEach(function (f) {
        f.addEventListener('submit', function (ev) {
            if (f.dataset.ok === '1') return;
            ev.preventDefault();
            pending = f;
            $('#confirm-judul').textContent = f.getAttribute('data-confirm-title') || 'Lanjutkan tindakan ini?';
            $('#confirm-teks').textContent = f.getAttribute('data-confirm');
            modal(cm, true);
        });
    });
    var ok = $('#confirm-ok');
    if (ok) ok.addEventListener('click', function () { if (pending) { pending.dataset.ok = '1'; pending.submit(); } });

    $$('[data-filter]').forEach(function (inp) {
        inp.addEventListener('input', function () {
            var q = inp.value.toLowerCase().trim();
            $$(inp.getAttribute('data-filter')).forEach(function (row) {
                row.style.display = row.textContent.toLowerCase().indexOf(q) > -1 ? '' : 'none';
            });
            var kosong = $(inp.getAttribute('data-empty') || '#none');
            if (kosong) {
                var tampil = $$(inp.getAttribute('data-filter')).some(function (r) { return r.style.display !== 'none'; });
                kosong.classList.toggle('hidden', tampil);
            }
        });
    });

    $$('[data-count]').forEach(function (el) { el.textContent = parseInt(el.getAttribute('data-count'), 10) || 0; });

    $$('[data-pass-toggle]').forEach(function (b) {
        b.addEventListener('click', function () {
            var i = $(b.getAttribute('data-pass-toggle'));
            if (i) i.type = i.type === 'password' ? 'text' : 'password';
        });
    });
})();
</script>
</body>
</html>